from django.contrib import admin

# Register your models here.

from.models import Account

@admin.register(Account)
class AccountAdmin(admin.ModelAdmin):
    list_display = ['username','pwd']

from.models import Employee

@admin.register(Employee)
class EmployeeAdmin(admin.ModelAdmin):
    list_display = ['fname','lname','title','emp_id']
