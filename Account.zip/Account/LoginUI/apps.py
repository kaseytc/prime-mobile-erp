from django.apps import AppConfig


class LoginuiConfig(AppConfig):
    name = 'LoginUI'
