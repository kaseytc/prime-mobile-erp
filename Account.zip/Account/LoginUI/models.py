from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
# Create your models here.
class Account(models.Model):
    acct_id = models.IntegerField(primary_key=True)
    username = models.CharField(max_length=50, blank=True, null=True)
    pwd = models.CharField(max_length=100, blank=True, null=True)
    acct_type = models.CharField(max_length=20, blank=True, null=True)
    emp = models.ForeignKey('Employee', on_delete=models.CASCADE, blank=True)

    class Meta:
        managed = False
        db_table = 'Account'


class Employee(models.Model):
    emp_id = models.IntegerField(primary_key=True)
    fname = models.CharField(max_length=50, blank=True, null=True)
    lname = models.CharField(max_length=50, blank=True, null=True)
    phone = models.CharField(max_length=12, blank=True, null=True)
    email = models.CharField(max_length=100, blank=True, null=True)
    manager_emp = models.ForeignKey('self', on_delete=models.CASCADE, blank=True, null=True)
    title = models.CharField(max_length=100, blank=True, null=True)
    addr1 = models.CharField(max_length=100, blank=True, null=True)
    addr2 = models.CharField(max_length=50, blank=True, null=True)
    city = models.CharField(max_length=50, blank=True, null=True)
    state = models.CharField(max_length=2, blank=True, null=True)
    zip = models.CharField(max_length=5, blank=True, null=True)
    dob = models.DateField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Employee'

def create_profile(sender, **kwargs):
    if kwargs['created']:
        user_profile = Account.objects.create(user=kwargs['instance'])
post_save.connect(create_profile, sender = User)

class Inventory(models.Model):
    inventory_id = models.IntegerField(primary_key=True)
    sku = models.CharField(max_length=12)
    make = models.CharField(max_length=50, blank=True, null=True)
    model = models.CharField(max_length=50, blank=True, null=True)
    inv_desc = models.TextField(blank=True, null=True)
    inv_price = models.IntegerField(blank=True, null=True)
    inv_cost = models.IntegerField(blank=True, null=True)
    quantity = models.IntegerField(blank=True, null=True)
    bin_aisle = models.IntegerField(blank=True, null=True)
    bin_bay = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Inventory'


class Invoice(models.Model):
    invoice_id = models.IntegerField(primary_key=True)
    invoice_dt = models.DateTimeField()
    pay_type = models.CharField(max_length=10, blank=True, null=True)
    emp = models.ForeignKey('Employee', on_delete=models.CASCADE, blank=True, null=True)
    invoice_num = models.IntegerField()

    class Meta:
        managed = False
        db_table = 'Invoice'

class Order(models.Model):
    order_id = models.IntegerField(primary_key=True)
    order_dt = models.DateTimeField(blank=True, null=True)
    status = models.CharField(max_length=20, blank=True, null=True)
    cust = models.ForeignKey('Customer',on_delete=models.CASCADE, blank=True, null=True)
    inventory = models.ForeignKey('Inventory',on_delete=models.CASCADE, blank=True, null=True )
    quantity = models.IntegerField(blank=True, null=True)
    invoice = models.ForeignKey('Invoice', on_delete=models.CASCADE, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Order'


class Customer(models.Model):
    cust_id = models.IntegerField(primary_key=True)
    fname = models.CharField(max_length=50, blank=True, null=True)
    lname = models.CharField(max_length=50, blank=True, null=True)
    phone = models.CharField(max_length=12, blank=True, null=True)
    email = models.CharField(max_length=100, blank=True, null=True)
    addr1 = models.CharField(max_length=100, blank=True, null=True)
    addr2 = models.CharField(max_length=50, blank=True, null=True)
    city = models.CharField(max_length=50, blank=True, null=True)
    state = models.CharField(max_length=2, blank=True, null=True)
    zip = models.CharField(max_length=5, blank=True, null=True)
    dob = models.DateField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'Customer'



