from django.conf.urls import url
from . import views
from django.contrib.auth.views import LoginView,LogoutView


urlpatterns = [
    url(r'^$', views.home),
    url(r'^login/$', LoginView.as_view(template_name='loginUI/index.html'), name='login'),
    url(r'^logout/$', LogoutView.as_view(template_name='loginUI/logout.html'), name='logout'),



]